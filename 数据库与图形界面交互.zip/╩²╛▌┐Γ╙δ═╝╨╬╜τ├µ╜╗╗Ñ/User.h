#if !defined(AFX_USER_H__2BCD50C3_7A8B_4413_AE82_0D8FEF5A66A6__INCLUDED_)
#define AFX_USER_H__2BCD50C3_7A8B_4413_AE82_0D8FEF5A66A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// User.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// User dialog

class User : public CDialog
{
// Construction
public:
	User(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(User)
	enum { IDD = IDD_DIALOG2 };
	CListCtrl	m_ListCtrl;
	CString	m_ID;
	CString	m_Name;
	CString	m_PWD;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(User)
	protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(User)
	afx_msg void Onadd();
	afx_msg void Onquery();
	afx_msg void Onmodify();
	afx_msg void Ondel();
	afx_msg void Onexit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USER_H__2BCD50C3_7A8B_4413_AE82_0D8FEF5A66A6__INCLUDED_)
