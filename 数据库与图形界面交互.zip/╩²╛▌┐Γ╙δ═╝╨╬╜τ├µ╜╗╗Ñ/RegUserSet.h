#if !defined(AFX_REGUSERSET_H__10904997_FB4B_425C_B10C_66774CF26B99__INCLUDED_)
#define AFX_REGUSERSET_H__10904997_FB4B_425C_B10C_66774CF26B99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RegUserSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRegUserSet recordset

class CRegUserSet : public CRecordset
{
public:
	CRegUserSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRegUserSet)

// Field/Param Data
	//{{AFX_FIELD(CRegUserSet, CRecordset)
	CString	m_RUID;
	CString	m_RUPWD;
	CString	m_RUName;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegUserSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REGUSERSET_H__10904997_FB4B_425C_B10C_66774CF26B99__INCLUDED_)
