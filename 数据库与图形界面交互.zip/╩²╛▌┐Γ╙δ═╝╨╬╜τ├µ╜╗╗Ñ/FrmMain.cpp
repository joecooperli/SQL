// FrmMain.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "FrmMain.h"
#include "User.h"
#include "frmRetireQuery.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FrmMain dialog


FrmMain::FrmMain(CWnd* pParent /*=NULL*/)
	: CDialog(FrmMain::IDD, pParent)
{
	//{{AFX_DATA_INIT(FrmMain)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void FrmMain::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FrmMain)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FrmMain, CDialog)
	//{{AFX_MSG_MAP(FrmMain)
	ON_BN_CLICKED(IDC_user, Onuser)
	ON_BN_CLICKED(IDC_query, Onquery)
	ON_BN_CLICKED(IDC_exit, Onexit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FrmMain message handlers

void FrmMain::Onuser() 
{
	User obj;
	//this->OnCancel ();
    obj.DoModal();

	
}

void FrmMain::Onquery() 
{
	frmRetireQuery obj;
	//this->OnCancel ();
    obj.DoModal();
	
}

void FrmMain::Onexit() 
{
	this->OnCancel();
	
}
