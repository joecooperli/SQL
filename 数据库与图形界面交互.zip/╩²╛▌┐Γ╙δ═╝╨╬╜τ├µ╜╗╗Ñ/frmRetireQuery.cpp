// frmRetireQuery.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "frmRetireQuery.h"
#include "RetireEmployeeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// frmRetireQuery dialog


frmRetireQuery::frmRetireQuery(CWnd* pParent /*=NULL*/)
	: CDialog(frmRetireQuery::IDD, pParent)
{
	//{{AFX_DATA_INIT(frmRetireQuery)
	m_check1 = FALSE;
	m_check2 = FALSE;
	m_check3 = FALSE;
	m_date1 = _T("");
	m_date2 = _T("");
	m_Name = _T("");
	m_birth = _T("");
	//}}AFX_DATA_INIT
}


void frmRetireQuery::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(frmRetireQuery)
	DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
	DDX_Check(pDX, IDC_CHECK1, m_check1);
	DDX_Check(pDX, IDC_CHECK2, m_check2);
	DDX_Check(pDX, IDC_CHECK3, m_check3);
	DDX_Text(pDX, IDC_date1, m_date1);
	DDX_Text(pDX, IDC_date2, m_date2);
	DDX_Text(pDX, IDC_empName, m_Name);
	DDX_Text(pDX, IDC_empBirth, m_birth);
	//}}AFX_DATA_MAP
}

BOOL frmRetireQuery::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString strHeader[7]={"����","��������","ѧ��","����","����ԭ��","��������","������"};
	m_ListCtrl.InsertColumn(0,strHeader[0],LVCFMT_LEFT,70);
	m_ListCtrl.InsertColumn(1,strHeader[1],LVCFMT_LEFT,190);
	m_ListCtrl.InsertColumn(2,strHeader[2],LVCFMT_LEFT,90);
	m_ListCtrl.InsertColumn(3,strHeader[3],LVCFMT_LEFT,90);
	m_ListCtrl.InsertColumn(4,strHeader[4],LVCFMT_LEFT,90);
	m_ListCtrl.InsertColumn(5,strHeader[5],LVCFMT_LEFT,90);
	m_ListCtrl.InsertColumn(6,strHeader[6],LVCFMT_LEFT,90);

	RetireEmployeeView  m_userset;
	CString str;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from retiredEmployee order by retireDate");
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	while(!m_userset.IsEOF())
	{
	    int nItem=m_ListCtrl.GetItemCount();
    	m_ListCtrl.InsertItem(nItem,m_userset.m_employeeName);
	    m_ListCtrl.SetItemText(nItem,1,m_userset.m_employeeBirth);
        m_ListCtrl.SetItemText(nItem,2,m_userset.m_employeeEdu);
		m_ListCtrl.SetItemText(nItem,3,m_userset.m_employeeMarry);
		m_ListCtrl.SetItemText(nItem,4,m_userset.m_retireCause);
		m_ListCtrl.SetItemText(nItem,5,m_userset.m_retireDate);
		m_ListCtrl.SetItemText(nItem,6,m_userset.m_retireHandleMan);   
		m_userset.MoveNext();
	}
	m_check1=false;
	m_check2=false;
	m_check3=false;
	return TRUE; 	              
}


BEGIN_MESSAGE_MAP(frmRetireQuery, CDialog)
	//{{AFX_MSG_MAP(frmRetireQuery)
	ON_BN_CLICKED(IDC_query, Onquery)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	ON_BN_CLICKED(IDC_exit, Onexit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// frmRetireQuery message handlers

void frmRetireQuery::Onquery() 
{
	UpdateData(TRUE);
	CString str="";
	CString conditionStr1="";
	CString conditionStr2="";
	CString conditionStr3="";
	if(this->m_check1!=0)
	{
		if(this->m_date1=="" && this->m_date1=="")
		{
			this->MessageBox("�������������ڣ�");
			return;
		}
		else
		{
			if(this->m_date1!="")
				conditionStr1="retireDate>='"+this->m_date1+"'";
			if(this->m_date2!="")
				if(conditionStr1=="")
					conditionStr1="retireDate<='"+this->m_date2+"'";
				else
                    conditionStr1=conditionStr1+" and retireDate<='"+this->m_date2+"'";

		}
	}
	if(this->m_check2!=0)
	{
		if(this->m_Name=="")
		{
			this->MessageBox("������������");
			return;
		}
		else
			conditionStr2="employeeName like '%"+this->m_Name+"%'";
	}
    if(this->m_check3!=0)
	{
		if(this->m_birth =="")
		{
			this->MessageBox("������������ڣ�");
			return;
		}
		else
			conditionStr3="employeeBirth like '%"+this->m_birth+"%'";
	}
	CString strCondition="";
    if(this->m_check1!=0)
		strCondition=conditionStr1;
    if(this->m_check2!=0)
		if(strCondition=="")
			strCondition=conditionStr2;
		else
			strCondition=strCondition+" and "+conditionStr2;

    if(this->m_check3!=0)
		if(strCondition=="")
			strCondition=conditionStr3;
		else
			strCondition=strCondition+" and "+conditionStr3;
    m_ListCtrl.DeleteAllItems();
	if(strCondition=="")
       str="select * from retiredEmployee  ";
	else
		str="select * from retiredEmployee where "+strCondition;
    RetireEmployeeView  m_userset;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
    m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	while(!m_userset.IsEOF())
	{
	    int nItem=m_ListCtrl.GetItemCount();
    	m_ListCtrl.InsertItem(nItem,m_userset.m_employeeName);
	    m_ListCtrl.SetItemText(nItem,1,m_userset.m_employeeBirth);
        m_ListCtrl.SetItemText(nItem,2,m_userset.m_employeeEdu);
		m_ListCtrl.SetItemText(nItem,3,m_userset.m_employeeMarry);
		m_ListCtrl.SetItemText(nItem,4,m_userset.m_retireCause);
		m_ListCtrl.SetItemText(nItem,5,m_userset.m_retireDate);
		m_ListCtrl.SetItemText(nItem,6,m_userset.m_retireHandleMan);   
		m_userset.MoveNext();
	}

	
}

void frmRetireQuery::OnCheck1() 
{
	if(m_check1!=0)
		this->m_check1=0;
	else
		m_check1=1;

	
}

void frmRetireQuery::OnCheck2() 
{
	if(m_check2!=0)
		this->m_check2=0;
	else
		m_check2=1;

	
}

void frmRetireQuery::OnCheck3() 
{
	if(m_check3!=0)
		this->m_check3=0;
	else
		m_check3=1;

	
}

void frmRetireQuery::Onexit() 
{
	this->OnCancel();
	
}
