// RetireEmployeeView.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "RetireEmployeeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// RetireEmployeeView


IMPLEMENT_DYNAMIC(RetireEmployeeView, CRecordset)

RetireEmployeeView::RetireEmployeeView(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(RetireEmployeeView)
	m_employeeBirth = _T("");
	m_employeeEdu = _T("");
	m_employeeID = _T("");
	m_employeeMarry = _T("");
	m_employeeMemo = _T("");
	m_employeeName = _T("");
	m_employeeState = 0;
	m_retireCause = _T("");
	m_retireDate = _T("");
	m_retireHandleMan = _T("");
	m_retireID = _T("");
	m_retireNo = _T("");
	m_nFields = 12;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString RetireEmployeeView::GetDefaultConnect()
{
	return _T("ODBC;DSN=HROdbc;UID=joe.cooper;PWD=lixufa520"); 
}

CString RetireEmployeeView::GetDefaultSQL()
{
	return _T("");
}

void RetireEmployeeView::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(RetireEmployeeView)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[employeeBirth]"), m_employeeBirth);
	RFX_Text(pFX, _T("[employeeEdu]"), m_employeeEdu);
	RFX_Text(pFX, _T("[employeeID]"), m_employeeID);
	RFX_Text(pFX, _T("[employeeMarry]"), m_employeeMarry);
	RFX_Text(pFX, _T("[employeeMemo]"), m_employeeMemo);
	RFX_Text(pFX, _T("[employeeName]"), m_employeeName);
	RFX_Long(pFX, _T("[employeeState]"), m_employeeState);
	RFX_Text(pFX, _T("[retireCause]"), m_retireCause);
	RFX_Text(pFX, _T("[retireDate]"), m_retireDate);
	RFX_Text(pFX, _T("[retireHandleMan]"), m_retireHandleMan);
	RFX_Text(pFX, _T("[retireID]"), m_retireID);
	RFX_Text(pFX, _T("[retireNo]"), m_retireNo);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// RetireEmployeeView diagnostics

#ifdef _DEBUG
void RetireEmployeeView::AssertValid() const
{
	CRecordset::AssertValid();
}

void RetireEmployeeView::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
