// User.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "User.h"
#include "RegUserSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// User dialog


User::User(CWnd* pParent /*=NULL*/)
	: CDialog(User::IDD, pParent)
{
	//{{AFX_DATA_INIT(User)
	m_ID = _T("");
	m_Name = _T("");
	m_PWD = _T("");
	//}}AFX_DATA_INIT
}


void User::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(User)
	DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
	DDX_Text(pDX, IDC_ID, m_ID);
	DDX_Text(pDX, IDC_Name, m_Name);
	DDX_Text(pDX, IDC_PWD, m_PWD);
	//}}AFX_DATA_MAP
}

BOOL User::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString strHeader[3]={"�ʺ�","����","����"};
	m_ListCtrl.InsertColumn(0,strHeader[0],LVCFMT_LEFT,170);
	m_ListCtrl.InsertColumn(1,strHeader[1],LVCFMT_LEFT,190);
	m_ListCtrl.InsertColumn(2,strHeader[2],LVCFMT_LEFT,290);

	CRegUserSet  m_userset;
	CString str;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser order by RUID");
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	while(!m_userset.IsEOF())
	{
		m_userset.GetFieldValue("RUID",m_ID); 
	    m_userset.GetFieldValue("RUPWD",m_PWD); 
	    m_userset.GetFieldValue("RUName",m_Name); 
	
	    int nItem=m_ListCtrl.GetItemCount();
    	m_ListCtrl.InsertItem(nItem,m_ID);
	    m_ListCtrl.SetItemText(nItem,1,m_Name);
        m_ListCtrl.SetItemText(nItem,2,m_PWD);
       
		m_userset.MoveNext();
	}
	return TRUE; 	              
}


BEGIN_MESSAGE_MAP(User, CDialog)
	//{{AFX_MSG_MAP(User)
	ON_BN_CLICKED(IDC_add, Onadd)
	ON_BN_CLICKED(IDC_query, Onquery)
	ON_BN_CLICKED(IDC_modify, Onmodify)
	ON_BN_CLICKED(IDC_del, Ondel)
	ON_BN_CLICKED(IDC_exit, Onexit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// User message handlers

void User::Onadd() 
{
	UpdateData(TRUE);
    CRegUserSet  m_userset;
	CString str;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser where RUID='%s' ", this->m_ID);
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	 int count=m_userset.GetRecordCount();
     if(count>0)
	 {

		 this->MessageBox("���ʺ��Ѵ��ڣ������������ʺţ�");
		 return;
	 }
	m_userset.AddNew();  
    m_userset.m_RUID=m_ID; 
	m_userset.m_RUPWD=m_PWD; 
	m_userset.m_RUName=m_Name; 
	m_userset.Update();
	int nItem=m_ListCtrl.GetItemCount();
	m_ListCtrl.InsertItem(nItem,m_ID);
	m_ListCtrl.SetItemText(nItem,1,m_Name);
    m_ListCtrl.SetItemText(nItem,2,m_PWD);
  

	this->MessageBox("�û����ӳɹ���");
	m_ID="";
	m_PWD="";
	m_Name="";
	UpdateData(false);
	m_userset.Close();

	
}

void User::Onquery() 
{
	UpdateData(TRUE);
    if(m_ID=="")
	{
		this->MessageBox("��ѯ�ʺŲ���Ϊ�գ�");
		return;
	}
	
	CRegUserSet  m_userset;
	CString str;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser where RUID='%s' ", this->m_ID);
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	int count=m_userset.GetRecordCount();
     if(count==0)
	 {

		 this->MessageBox("���ʺ��û������ڣ�");
		 return;
	 }
     m_userset.GetFieldValue("RUID",m_ID); 
	 m_userset.GetFieldValue("RUPWD",m_PWD); 
	 m_userset.GetFieldValue("RUName",m_Name); 
	 
	UpdateData(false);
	m_userset.Close();

	
}

void User::Onmodify() 
{
	UpdateData(TRUE);
    if(m_ID=="")
	{
		this->MessageBox("�ʺŲ���Ϊ�գ��������ʺţ�");
		return;
	}
	
	CRegUserSet  m_userset;
	CString str;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser where RUID='%s' ", this->m_ID);
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	int count=m_userset.GetRecordCount();
     if(count==0)
	 {

		 this->MessageBox("���ʺ��û������ڣ������޸ģ�");
		 return;
	 }

	 m_userset.Edit();
     m_userset.m_RUID=m_ID; 
	m_userset.m_RUPWD=m_PWD; 
	m_userset.m_RUName=m_Name; 
	m_userset.Update();
	m_userset.Requery();
	m_ListCtrl.DeleteAllItems() ; 
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser order by RUID");
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	while(!m_userset.IsEOF())
	{
		m_userset.GetFieldValue("RUID",m_ID); 
	    m_userset.GetFieldValue("RUPWD",m_PWD); 
	    m_userset.GetFieldValue("RUName",m_Name); 
	    int nItem=m_ListCtrl.GetItemCount();
    	m_ListCtrl.InsertItem(nItem,m_ID);
	    m_ListCtrl.SetItemText(nItem,1,m_Name);
        m_ListCtrl.SetItemText(nItem,2,m_PWD);
       
		m_userset.MoveNext();
	}
	this->MessageBox("�û��޸ĳɹ���");
	m_ID="";
	m_PWD="";
	m_Name="";
	
	UpdateData(false);
	m_userset.Close();

	
}

void User::Ondel() 
{
	UpdateData(TRUE);
    if(m_ID=="")
	{
		this->MessageBox("ɾ���û��ʺŲ���Ϊ�գ�");
		return;
	}
	
	CRegUserSet  m_userset;
	CString str;
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser where RUID='%s' ", this->m_ID);
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	int count=m_userset.GetRecordCount();
     if(count==0)
	 {

		 this->MessageBox("���ʺ��û������ڣ�����ɾ����");
		 return;
	 }
	CRecordsetStatus status; 
    m_userset.GetStatus(status); // ��ȡ��ǰ��¼��״̬ 
    m_userset.Delete(); // ɾ����ǰ��¼ 
    if (status.m_lCurrentRecord==0) // ��ǰ��¼�����ţ�0��ʾ��һ����¼ 
        m_userset.MoveNext(); // ����һ����¼ 
    else 
		m_userset.MoveFirst(); // �ƶ�����һ����¼��

	m_ListCtrl.DeleteAllItems() ; 
	if(m_userset.IsOpen())
	{
		m_userset.Close();
	}
	str.Format("select * from regUser order by RUID");
	m_userset.Open(AFX_DB_USE_DEFAULT_TYPE,str);
	while(!m_userset.IsEOF())
	{
		m_userset.GetFieldValue("RUID",m_ID); 
	    m_userset.GetFieldValue("RUPWD",m_PWD); 
	    m_userset.GetFieldValue("RUName",m_Name); 
	
	    int nItem=m_ListCtrl.GetItemCount();
    	m_ListCtrl.InsertItem(nItem,m_ID);
	    m_ListCtrl.SetItemText(nItem,1,m_Name);
        m_ListCtrl.SetItemText(nItem,2,m_PWD);
       
		m_userset.MoveNext();
	}
	this->MessageBox("�û�ɾ���ɹ���");

    m_ID="";
	m_PWD="";
	m_Name="";
	UpdateData(false);
	m_userset.Close();	

	
}

void User::Onexit() 
{
	this->OnCancel();
	
}
