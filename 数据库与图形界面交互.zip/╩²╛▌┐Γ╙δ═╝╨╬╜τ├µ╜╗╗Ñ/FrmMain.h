#if !defined(AFX_FRMMAIN_H__18B6A6BC_D879_4299_B74B_803B011ED0D2__INCLUDED_)
#define AFX_FRMMAIN_H__18B6A6BC_D879_4299_B74B_803B011ED0D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FrmMain.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FrmMain dialog

class FrmMain : public CDialog
{
// Construction
public:
	FrmMain(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(FrmMain)
	enum { IDD = IDD_DIALOG1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FrmMain)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(FrmMain)
	afx_msg void Onuser();
	afx_msg void Onquery();
	afx_msg void Onexit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FRMMAIN_H__18B6A6BC_D879_4299_B74B_803B011ED0D2__INCLUDED_)
