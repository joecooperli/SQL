// RegUserSet.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "RegUserSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegUserSet

IMPLEMENT_DYNAMIC(CRegUserSet, CRecordset)

CRegUserSet::CRegUserSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRegUserSet)
	m_RUID = _T("");
	m_RUPWD = _T("");
	m_RUName = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRegUserSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=HROdbc;UID=joe.cooper;PWD=lixufa520"); 
}

CString CRegUserSet::GetDefaultSQL()
{
	return _T("[dbo].[regUser]");
}

void CRegUserSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRegUserSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[RUID]"), m_RUID);
	RFX_Text(pFX, _T("[RUPWD]"), m_RUPWD);
	RFX_Text(pFX, _T("[RUName]"), m_RUName);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRegUserSet diagnostics

#ifdef _DEBUG
void CRegUserSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRegUserSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
