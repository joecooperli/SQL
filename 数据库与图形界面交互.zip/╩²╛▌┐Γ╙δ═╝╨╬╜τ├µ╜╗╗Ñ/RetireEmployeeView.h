#if !defined(AFX_RETIREEMPLOYEEVIEW_H__96A5A015_C286_44DF_8386_D6AA06A9B890__INCLUDED_)
#define AFX_RETIREEMPLOYEEVIEW_H__96A5A015_C286_44DF_8386_D6AA06A9B890__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RetireEmployeeView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// RetireEmployeeView recordset

class RetireEmployeeView : public CRecordset
{
public:
	RetireEmployeeView(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(RetireEmployeeView)

// Field/Param Data
	//{{AFX_FIELD(RetireEmployeeView, CRecordset)
	CString	m_employeeBirth;
	CString	m_employeeEdu;
	CString	m_employeeID;
	CString	m_employeeMarry;
	CString	m_employeeMemo;
	CString	m_employeeName;
	long	m_employeeState;
	CString	m_retireCause;
	CString	m_retireDate;
	CString	m_retireHandleMan;
	CString	m_retireID;
	CString	m_retireNo;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(RetireEmployeeView)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RETIREEMPLOYEEVIEW_H__96A5A015_C286_44DF_8386_D6AA06A9B890__INCLUDED_)
